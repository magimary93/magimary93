from django.urls import path
from .views import ListEmployeesView,EmployeeCreateApi,EmployeeUpdateApi,EmployeeDeleteApi,EmployeePagination
urlpatterns = [path('employee_view/',ListEmployeesView.as_view(),name='employees-all'),
               path('employee_create/',EmployeeCreateApi.as_view(),name='employees-create'),
               path('employee_update/<int:pk>/',EmployeeUpdateApi.as_view(),name='employees-update'),
               path('employee_delete/<int:pk>/',EmployeeDeleteApi.as_view(),name='employees-delete'),
               path('employee_list/',EmployeePagination.as_view(),name='employees-page'),
               
               ]
