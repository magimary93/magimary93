from rest_framework import generics
from .models import Employees
from .serializers import EmployeesSerializer
from rest_framework.pagination import PageNumberPagination
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend

class ListEmployeesView(generics.ListAPIView):
    queryset=Employees.objects.all()
    serializer_class=EmployeesSerializer
class EmployeeCreateApi(generics.CreateAPIView):
    queryset = Employees.objects.all()
    serializer_class = EmployeesSerializer
class EmployeeUpdateApi(generics.RetrieveUpdateAPIView):
    queryset = Employees.objects.all()
    serializer_class = EmployeesSerializer
class EmployeeDeleteApi(generics.DestroyAPIView):
    queryset = Employees.objects.all()
    serializer_class = EmployeesSerializer
class SetPagination(PageNumberPagination):
     page_size=1
class EmployeePagination(generics.ListAPIView):
    queryset=Employees.objects.all()
    serializer_class=EmployeesSerializer
    pagination_class=SetPagination
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['firstname']
    
    
