from django.db import models

class Employees(models.Model):
    id=models.IntegerField(primary_key=True,null=False)
    firstname=models.CharField(max_length=255,null=False)
    lastname=models.CharField(max_length=255,null=False)
    designation=models.CharField(max_length=255,null=False)
    def __str__(self):
        return self.firstname
